from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    APP_NAME: str = "Driver Compliance Watch Managed SaaS"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    SECRET_KEY: str = "default_secret_key"

    DATABASE_URL: str = "postgresql+asyncpg://dcw_user:dcw_secure_password@localhost:5432/dcw_compliance_db"
    REDIS_URL: str = "redis://localhost:6379/0"

settings = Settings()
